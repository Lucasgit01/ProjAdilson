/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
/**
 *
 * @author alunocmc
 */


public class Lojas{
    // Atrib.
    private int id;
    private String cnpj;
    private String nome;
    private String email;  
    private String resp;
    
    // Métodos
    public Lojas() {
    }
    public Lojas(int p_id, String p_cnpj, String p_nome, String p_email, String p_resp){
        this.id = p_id;
        this.cnpj = p_cnpj;
        this.nome = p_nome;
        this.email = p_email;
        this.resp = p_resp;
    }


    public void setId(int p_id) {
        this.id = p_id;    
    }
    public void setCnpj(String p_cnpj) {
        this.cnpj = p_cnpj;    
    }
    public void setNome(String p_nome) {
        this.nome = p_nome;    
    }
    public void setEmail(String p_email) {
        this.email = p_email;
    }
    public void setResp(String p_resp) {
        this.resp = p_resp;
    }
    

    public int getId() {
        return this.id;    
    }
    public String getCnpj() {
        return this.cnpj;
    }
    public String getNome() {
        return this.nome;
    }
    public String getEmail() {
        return this.email;
    }   
    public String getResp() {
        return this.resp;
    }
}