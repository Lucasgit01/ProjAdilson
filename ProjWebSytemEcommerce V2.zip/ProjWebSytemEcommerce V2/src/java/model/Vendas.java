/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author alunocmc
 */


public class Vendas {
    // Atrib.
    private int id;
    private String loja;
    private String produto;
    private int quantidade;  
    private double preco;
    private double total;
    private Date data;
    private String situacao;
    
    // Métodos
    public Vendas() {
    }

    public Vendas(int id, String loja, String produto, int quantidade, double preco, double total, Date data, String situacao) {
        this.id = id;
        this.loja = loja;
        this.produto = produto;
        this.quantidade = quantidade;
        this.preco = preco;
        this.total = total;
        this.data = data;
        this.situacao = situacao;
    }

    public int getId() {
        return id;
    }

    public String getLoja() {
        return loja;
    }

    public String getProduto() {
        return produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getPreco() {
        return preco;
    }

    public double getTotal() {
        return total;
    }

    public Date getData() {
        return data;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setLoja(String loja) {
        this.loja = loja;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

}
