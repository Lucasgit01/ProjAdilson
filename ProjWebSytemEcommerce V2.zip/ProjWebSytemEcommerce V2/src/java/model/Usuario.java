/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author alunocmc
 */
public class Usuario {
    // Atrib.
    private int codigo;
    private String nome;
    private String user;
    private String senha;
    private String setor;    
    
    // Métodos
    public Usuario() {
    }
    public Usuario(int p_codigo, String p_nome, String p_user, String p_senha, String p_setor){
        this.codigo = p_codigo;
        this.nome = p_nome;
        this.user = p_user;
        this.senha = p_senha;
        this.setor = p_setor;
    }

    public void setSetor(String p_setor) {
        this.setor = p_setor;
    }
    
    public void setCod(int p_codigo) {
        this.codigo = p_codigo;    
    }
    public void setNome(String parametro_nome) {
        this.nome = parametro_nome;    
    }
    public void setUser(String p_user) {
        this.user = p_user;    
    }
    public void setSenha(String p_senha) {
        this.senha = p_senha;
    }
    public int getCod() {
        return this.codigo;
    }
    public String getNome() {
        return this.nome;
    }
    public String getUser() {
        return this.user;
    }
    public String getSenha() {
        return this.senha;
    } 

    public String getSetor() {
        return this.setor;
    }  
}
