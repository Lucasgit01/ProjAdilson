package dao;

import model.Vendas;
import util.ConectaDB;
import java.sql.*;
import java.text.*;
import java.util.ArrayList;
import java.util.List;



/**
 *
 * @author alunocmc
 */
public class VendasDAO {
    // Zero Atrib.
    
    // Métodos - CRUD
   
    
    //Consultas
    public List consultar_lista_simples() throws ClassNotFoundException, ParseException{
        List lista = new ArrayList();
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement(); //Cria uma instrução
            //String sql = "SELECT * FROM vendas";
            String sql = "SELECT * FROM vendas";
            ResultSet rs = stmt.executeQuery(sql); // Select
            
            int n_reg = 0;
            while (rs.next()){
               Vendas vendas = new Vendas();
               vendas.setId(Integer.parseInt( rs.getString("id")));
               vendas.setLoja(rs.getString("loja"));
               vendas.setProduto(rs.getString("produto"));
               vendas.setQuantidade(Integer.parseInt( rs.getString("quantidade")));
               vendas.setPreco(Double.parseDouble(rs.getString("preco") ));
               vendas.setTotal(Double.parseDouble(rs.getString("total") ));
               vendas.setData(rs.getDate("data"));  
               vendas.setSituacao(rs.getString("situacao"));
               lista.add(vendas);
               n_reg++;
            }
                
            if (n_reg == 0){
                return null;
            }else{
                return lista;
            }            
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);    
            return null;
        }               
    }

    
    public Vendas consultar_id(Vendas p_vd) throws ClassNotFoundException, ParseException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement(); //Cria uma instrução
            //String sql = "SELECT * FROM vendas WHERE pk_id = 7";
            String sql = "SELECT * FROM vendas WHERE id = " + p_vd.getId();
            ResultSet rs = stmt.executeQuery(sql); // Select
            
            int n_reg = 0;
            while (rs.next()){
               p_vd.setId(Integer.parseInt( rs.getString("id")));
              p_vd.setLoja(rs.getString("loja"));
               p_vd.setProduto(rs.getString("produto"));
              p_vd.setQuantidade(Integer.parseInt( rs.getString("quantidade")));
              p_vd.setPreco(Double.parseDouble(rs.getString("preco") ));
               p_vd.setTotal(Double.parseDouble(rs.getString("total") ));
               p_vd.setData(rs.getDate("data"));  
               p_vd.setSituacao(rs.getString("situacao"));
               n_reg++;
            }
                
            if (n_reg == 0){
                return null;
            }else{
                return p_vd;
            }            
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);    
            return null;
        }               
    }
    
    public List<Vendas> consultar_datas(String dataInicial, String dataFinal) throws SQLException, ParseException, ClassNotFoundException {
        
        
        
        
        
        List<Vendas> resultados = new ArrayList();
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try(Connection conexao = ConectaDB.conectar();){
            // Converte as datas de String para java.sql.Date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date sqlDataInicial =  (java.util.Date) sdf.parse(dataInicial);
            java.util.Date sqlDataFinal =  (java.util.Date) sdf.parse(dataFinal);

            // Consulta SQL com parâmetros
            String sql = "SELECT * FROM vendas WHERE data BETWEEN ? AND ?";
            preparedStatement = conexao.prepareStatement(sql);
             preparedStatement.setDate(1, new java.sql.Date(sqlDataInicial.getTime()));
            preparedStatement.setDate(2, new java.sql.Date(sqlDataFinal.getTime()));

            rs = preparedStatement.executeQuery();
            
            
            // Processa os resultados
           int n_reg = 0;
            
          while (rs.next()) {
              Vendas p_vd = new Vendas();
                p_vd.setId(Integer.parseInt( rs.getString("id")));
              p_vd.setLoja(rs.getString("loja"));
               p_vd.setProduto(rs.getString("produto"));
              p_vd.setQuantidade(Integer.parseInt( rs.getString("quantidade")));
              p_vd.setPreco(Double.parseDouble(rs.getString("preco") ));
               p_vd.setTotal(Double.parseDouble(rs.getString("total") ));
               p_vd.setData(rs.getDate("data"));  
               p_vd.setSituacao(rs.getString("situacao"));
            
            resultados.add(p_vd);
            n_reg++;
 
          }
          if (n_reg == 0){
                return null;
            }else{
                return resultados;
            }   
        
        } catch (SQLException e) {
            
             return null;
       
            }
       
         }
    
    //alterar
    public boolean alterar(Vendas p_vd) throws ClassNotFoundException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();
          //String sql = "UPDATE vendas SET nome='Amanda de Souza', renda= 7500, nasc='2020/04/20' WHERE codigo = 700";
            String sql = "UPDATE vendas SET situacao= '" + p_vd.getSituacao() + "' WHERE id= " + p_vd.getId(); 
                                                                                                                                                                                                                              
            stmt.executeUpdate(sql); // Insert - Update - Delete
            return true;
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }

}

