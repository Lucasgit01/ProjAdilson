package dao;

import model.Lojas;
import util.ConectaDB;
import java.sql.*;
import java.text.*;
import java.util.ArrayList;
import java.util.List;

public class LojasDAO {
    // Zero Atrib.
    
    // Métodos - CRUD
    public boolean inserir (Lojas p_lj) throws ClassNotFoundException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();
            //String sql = "Insert into Lojas (codigo, nome, renda, nasc) values(987654, 'José da Silva', 9500, '1981/03/22')";
            String sql = "Insert into lojas (cnpj, nome, email, responsavel) values('" + p_lj.getCnpj() + "', '" + 
                                                                                     p_lj.getNome() + "', '" + 
                                                                                    p_lj.getEmail() + "', '"+ p_lj.getResp()+ "' )";
                                                                                            // SimpleDateFormat("dd/MM/yyyy").format(func.getNasc())
            stmt.executeUpdate(sql); // Insert - Update - Delete
            return true;
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }

    //Consultas
    public List visualizar_lista_simples() throws ClassNotFoundException, ParseException{
        List listed = new ArrayList();
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement(); //Cria uma instrução
            //String sql = "SELECT * FROM Lojas";
            String sql = "SELECT * FROM lojas";
            ResultSet res = stmt.executeQuery(sql); // Select
            
            int n_reg = 0;
            while (res.next()){
               Lojas lojas = new Lojas();
               lojas.setId(Integer.parseInt( res.getString("id")));
               lojas.setCnpj(res.getString("cnpj"));
               lojas.setNome(res.getString("nome"));
               lojas.setEmail(res.getString("email"));
               lojas.setResp(res.getString("responsavel"));  
               listed.add(lojas);
               n_reg++;
            }
                
            if (n_reg == 0){
                return null;
            }else{
                return listed;
            }            
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);    
            return null;
        }               
    }

    public Lojas pesquisar(Lojas p_lj) throws ClassNotFoundException, ParseException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement(); //Cria uma instrução
            //String sql = "SELECT * FROM Lojas WHERE pk_id = 7";
            String sql = "SELECT * FROM lojas WHERE id = " + p_lj.getId()  ;
            ResultSet rs = stmt.executeQuery(sql); // Select
            
            int n_reg = 0;
            while (rs.next()){
               p_lj.setCnpj(rs.getString("cnpj"));
               p_lj.setNome(rs.getString("nome"));
               p_lj.setEmail(rs.getString("email"));
               p_lj.setResp(rs.getString("responsavel"));
               n_reg++;
            }
                
            if (n_reg == 0){
                return null;
            }else{
                return p_lj;
            }            
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);    
            return null;
        }               
    }
    
    
    //excluir_id
    public boolean excluir(Lojas p_lj) throws ClassNotFoundException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();            
            String sql = "DELETE from lojas WHERE id = " + p_lj.getId();          
            stmt.executeUpdate(sql); // Insert - Update - Delete
            return true;
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }
    
    //alterar
    public boolean alter(Lojas p_lj) throws ClassNotFoundException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();
          //String sql = "UPDATE Lojas SET nome='Amanda de Souza', renda= 7500, nasc='2020/04/20' WHERE codigo = 700";
            String sql = "UPDATE lojas SET cnpj = '"+ p_lj.getCnpj() +"', nome='" + p_lj.getNome() + "', email= '" + p_lj.getEmail() + "', responsavel='" + p_lj.getResp() +
                                                                          "' WHERE id = " + p_lj.getId();                                                                                                                        
            stmt.executeUpdate(sql); // Insert - Update - Delete
            return true;
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }

}
